to compile and run : 
1. g++ main.cpp
2. ./a.out
3. Enter the name of input file : input.txt
4. Enter starting address : 4000